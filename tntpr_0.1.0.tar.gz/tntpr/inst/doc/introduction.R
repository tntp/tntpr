## ----setup,echo=FALSE, include = FALSE-----------------------------------
library(knitr)
knitr::opts_chunk$set(error = TRUE)
knitr::opts_chunk$set(out.width='750px', dpi = 300)
knitr::opts_chunk$set(dev = "png", fig.width = 8, fig.height = 4.8889, dpi = 300)

## ----load_packages, include = FALSE--------------------------------------
library(pacman)
if(!require("tntpr")) install_git("https://tools.tntp.org/bitbucket/scm/ct/tntpr.git"); library(tntpr)
p_load(ggplot2, dplyr, janitor, ggrepel)

## ----colors--------------------------------------------------------------
palette_tntp("dark_blue", "orange", "light_gray")

## ----theme_tntp----------------------------------------------------------
ggplot(mtcars, aes(x = cyl)) +
  geom_bar(fill = palette_tntp("dark_blue")) +
  theme_tntp()

## ----chart_functions-----------------------------------------------------
bar_chart_counts(wisc, proflvl, var_label = "Proficiency Level")
bar_chart_counts(wisc,
                 race,
                 proflvl,
                 var_label = "Race",
                 labels = "pct",
                 title = "Distribution of Proficiency Levels by Student Race",
                 digits = 0)

## ------------------------------------------------------------------------
hire_dates <- c(as.Date("2015-08-31"), as.Date("2015-10-20"), as.Date("2016-08-08"),
                as.Date("2016-08-31"), as.Date("2016-09-15"))
date_to_sy(hire_dates, last_day_of_sy = as.Date("2000-09-01")) # the year doesn't matter

## ------------------------------------------------------------------------
convert_to_top_2_agree <- function(x, custom_vals = NULL){
  if(is.null(custom_vals)){
    custom_vals <- c("strongly agree", "agree", "highly satisfied", "extremely satisfied",
                     "satisfied", "very confident", "confident")
    x <- tolower(x)
  }
  if_else(is.na(x), as.character(NA),
          if_else(x %in% custom_vals, "Top-2 Agree", "Not in Top-2"))
}

convert_to_top_2_agree(c("Strongly agree", "Agree", "Somewhat agree", NA, NA, "Strongly disagree")) %>%
  tabyl

## ------------------------------------------------------------------------
# Write function to determine whether someone left the location the next year
left_campus <- function(first_year, second_year){
  if_else(is.na(first_year), NA,
         if_else(is.na(second_year), TRUE,
                if_else(first_year != second_year, TRUE, FALSE)))
}

## ------------------------------------------------------------------------
# From Noble St. contract, July 2016, Danielle Proulx
# Formula for detailing yearly movement
yearly_movement <- function(first_year, second_year){
  case_when(
    is.na(first_year) & is.na(second_year) ~ "Not Present",
    is.na(first_year) & second_year == "Teacher" ~ "Joined as Teacher",
    is.na(first_year) & second_year == "Leader" ~ "Joined as Leader",
    is.na(first_year) & second_year == "Other" ~ "Joined as Other"
    ,
    first_year == "Teacher" & is.na(second_year) ~ "Teacher Left",
    first_year == "Leader" & is.na(second_year) ~ "Leader Left",
    first_year == "Other" & is.na(second_year) ~ "Other Left",
    
    first_year == "Teacher" & second_year == "Teacher" ~ "Remained Teacher",
    first_year == "Teacher" & second_year == "Leader" ~ "Teacher became Leader",
    first_year == "Teacher" & second_year == "Other" ~ "Teacher became Other",
    
    first_year == "Leader" & second_year == "Leader" ~ "Remained Leader",
    first_year == "Leader" & second_year == "Teacher" ~ "Leader became Teacher",
    first_year == "Leader" & second_year == "Other" ~ "Leader became Other",
   
    first_year == "Other" & second_year == "Teacher" ~ "Other became Teacher",
    first_year == "Other" & second_year == "Leader" ~ "Other became Leader",
    first_year == "Other" & second_year == "Other" ~ "Remained Other",
    TRUE ~ "bad formula!!!"
  )
}

