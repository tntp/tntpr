# tntp R package
`r Sys.Date()`  

## About

The `tntpr` package makes data science at TNTP easier and more accurate by supplying tools that are needed for common TNTP analyses.  Because this package serves just the TNTP analysis community, functions can be tailored very specifically to our exact use cases.

To get a sense of the possibilities for an internal TNTP package, consider this [blog post from Airbnb](https://medium.com/airbnb-engineering/using-r-packages-and-education-to-scale-data-science-at-airbnb-906faa58e12d#.6xtwqtk4m) on their internal R package, "Rbnb".

## Package summary

Some of the highlights of the package include:

- TNTP-themed RMarkdown templates, for starting a new analysis with a shell that can already generate a TNTP-themed .docx report 
- TNTP-specific ggplot2 theme and color palette
- Wrappers for quickly making typical TNTP-style charts (e.g., bar chart of means on variable 1 grouped by variable 2)
- Education-specific data management functions (e.g., `date_to_SY()` to convert continuous hire dates into school years using a specified cutoff date)

`tntpr` is built to work seamlessly with the "tidyverse," a set of packages outlined in the wiki page [Overview of R at TNTP](https://tools.tntp.org/confluence/display/TOPIC/Overview+of+R+at+TNTP).

## Installing the package

This package is not on CRAN, and probably will not ever be.  You'll need to install this package from its Bitbucket repository.  You can add this to the top of your analysis script:

```
# install tntpr if you don't already have it, then load it
library(devtools) # for install_git()
if(!require("tntpr")) install_git("https://tools.tntp.org/bitbucket/scm/ct/tntpr.git")
library(tntpr)
```

This won't check for updates, though.  So for now, consider periodically running the `install_git(...)` part anyway.  Once it's installed, you can load it however you normally load packages, say with `pacman::p_load(tntpr)`.

## Using the package

See the [vignette](https://tools.tntp.org/bitbucket/projects/CT/repos/tntpr/browse/vignettes/introduction.md) for demonstrations of how to use these tntpr functions.

## Feature Requests and Bug Reports

Please tell us what data problems you’re repeatedly encountering and need help 
with, and what bugs you find while working with the `tntpr` package. We’re 
[tracking these issues on the wiki.](https://tools.tntp.org/confluence/display/TOPIC/tntpr+R+package)
